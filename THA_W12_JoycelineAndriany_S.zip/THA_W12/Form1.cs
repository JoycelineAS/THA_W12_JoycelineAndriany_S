﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace THA_W12
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string query;
        DataTable dt_TeamInput = new DataTable();
        DataTable dt_TeamFilterPl = new DataTable();
        DataTable dt_TeamFilterMan = new DataTable();
        DataTable dt_Nat = new DataTable();
        DataTable dt_Plyr = new DataTable();
        DataTable dt_Man = new DataTable();

        DataTable dtDGVPlayer = new DataTable();
        DataTable dtDGVManagerWorking = new DataTable();
        DataTable dtDGVManagerNonWorking = new DataTable();
        DataTable dtDGVNationality= new DataTable();
        DataTable dtDGVTeam= new DataTable();
        public Form1()
        {
            try
            {
                string connection = "server=localhost;uid=root;pwd=;database=premier_league";
                sqlConnection = new MySqlConnection(connection);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            InitializeComponent();
            DGV1.DataSource = dt_Plyr;
            DGV2.DataSource = dt_Man;   
        }
        private void updateDGV1()
        {
            dt_Plyr.Clear();
            try
            {
                string command = "select * from player";
                sqlCommand = new MySqlCommand(command, sqlConnection);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt_Plyr);
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void updateDGV2()
        {
            //dtDGVManager.Clear();
            //try
            //{
            //    string command = "select * from manager";
            //    sqlCommand = new MySqlCommand(command, sqlConnection);
            //    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            //    sqlDataAdapter.Fill(dtDGVManager);
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}

        }
        private void updateDGVManagerNotWorking() {
            dtDGVManagerNonWorking.Clear();
            //$"SELECT m.manager_name, m.birthdate,n.nation from manager m, team t, nationality n where t.manager_id = m.manager_id and n.nationality_id = m.nationality_id and t.team_id = '{cbTeam2.SelectedValue.ToString()}';";
            //string team_id = cbTeam3.SelectedValue.ToString();
            string command =
            $@"SELECT m.manager_id, m.manager_name as name, m.birthdate, n.nation as nationality
                    FROM manager m
                LEFT JOIN team t on m.manager_id = t.manager_id
                LEFT JOIN nationality n on m.nationality_id = n.nationality_id
                WHERE m.`delete` = 0  AND m.working=0 ";
            sqlCommand = new MySqlCommand(command, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtDGVManagerNonWorking);
            DGV3.DataSource = dtDGVManagerNonWorking;
            DGV3.Columns[0].Visible = false;
        }
        private void cbTeam3_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtDGVManagerWorking.Clear();
            //$"SELECT m.manager_name, m.birthdate,n.nation from manager m, team t, nationality n where t.manager_id = m.manager_id and n.nationality_id = m.nationality_id and t.team_id = '{cbTeam2.SelectedValue.ToString()}';";
            string team_id = cbTeam3.SelectedValue.ToString();
            string command =
            $@"SELECT m.manager_id, m.manager_name as name, t.team_name as team_name, m.birthdate, n.nation as nationality
                    FROM manager m
                LEFT JOIN team t on m.manager_id = t.manager_id
                LEFT JOIN nationality n on m.nationality_id = n.nationality_id
                WHERE m.`delete` = 0  AND m.working=1 AND t.team_id='{team_id}'";
            sqlCommand = new MySqlCommand(command, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtDGVManagerWorking);
            DGV2.DataSource = dtDGVManagerWorking;
            DGV2.Columns[0].Visible = false;
        }
        private void comboBoxTeam2_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtDGVPlayer.Clear();
            //$"SELECT m.manager_name, m.birthdate,n.nation from manager m, team t, nationality n where t.manager_id = m.manager_id and n.nationality_id = m.nationality_id and t.team_id = '{cbTeam2.SelectedValue.ToString()}';";
            string team_id = cbTeam2.SelectedValue.ToString();
            string command =
            $@"SELECT p.player_id, p.team_id, p.player_name, n.nation, p.playing_pos, p.team_number, p.height, p.weight, p.birthdate
                FROM player p
            LEFT join nationality n on p.nationality_id = n.nationality_id
            WHERE status=1 AND p.`delete`=0 AND team_id='{team_id}'";
            sqlCommand = new MySqlCommand(command, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtDGVPlayer);
            DGV1.DataSource = dtDGVPlayer;
            DGV1.Columns[0].Visible = false;
            DGV1.Columns[1].Visible = false;
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            query = "SELECT team_name,team_id FROM team;";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt_TeamFilterPl);
            cbTeam2.DataSource = dt_TeamFilterPl;
            cbTeam2.ValueMember = "team_id";
            cbTeam2.DisplayMember = "team_name";
            

            query = "SELECT team_name,team_id FROM team;";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt_TeamFilterMan);
            cbTeam3.DataSource = dt_TeamFilterMan;
            cbTeam3.ValueMember = "team_id";
            cbTeam3.DisplayMember = "team_name";

            query = "SELECT team_name,team_id FROM team;";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt_TeamInput);
            cbTeam1.DataSource = dt_TeamInput;
            cbTeam1.ValueMember = "team_id";
            cbTeam1.DisplayMember = "team_name";


            query = "SELECT nation,nationality_id FROM nationality;";
            sqlCommand = new MySqlCommand(query, sqlConnection);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt_Nat);
            comboBoxNat.DataSource = dt_Nat;
            comboBoxNat.ValueMember = "nationality_id";
            comboBoxNat.DisplayMember = "nation";

            updateDGVManagerNotWorking();

            //updateDGV1();

        }


        private void button1_Click(object sender, EventArgs e)
        {
            string name = tbName.Text;
            string teamnum = tbTeamnum.Text;
            string nationality = comboBoxNat.SelectedValue.ToString();
            string position = tbPosition.Text;
            string height = tbHeight.Text;
            string weight = tbWeight.Text;
            string birth = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            string teamname = cbTeam1.SelectedValue.ToString();
            string firstChar = (name[0] + "").ToUpper();
            string query = $@"
                SELECT COUNT(p.player_id) as totalPlayer
                    FROM player p 
                WHERE p.player_name LIKE '{firstChar}%'";
            sqlConnection.Open();
            sqlCommand = new MySqlCommand(query, sqlConnection);
            // CARA MANUAL
            //for (int i = 0; i < length; i++)
            //{
            //    if char 1 == firstChar ,, current counter ++
            //}

            int totalPlayer = Int32.Parse(sqlCommand.ExecuteScalar().ToString())+1;

            sqlConnection.Close();
            string playerid = firstChar + totalPlayer.ToString().PadLeft(3,'0');
            string command = $@"INSERT INTO player 
                (player_id,team_number,player_name,nationality_id,playing_pos,
                height,weight,birthdate,team_id,
                status,`delete`) VALUES 
                ('{playerid}','{teamnum}','{name}','{nationality}','{position}',
                '{height}','{weight}','{birth}','{teamname}',
                1,0);";

            try
            {
                sqlConnection.Open();
                sqlCommand = new MySqlCommand(command, sqlConnection);
                int result = sqlCommand.ExecuteNonQuery(); 
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);    
            }
            finally
            {
                sqlConnection.Close();
                comboBoxTeam2_SelectedIndexChanged(null, null);
            }

        }


        private void btnDel_Click(object sender, EventArgs e)
        {
            string team_id = DGV1.SelectedRows[0].Cells[1].Value.ToString();
            string query = $@"
                SELECT COUNT(p.player_id) as totalPlayer
                    FROM team t
                INNER JOIN player p on t.team_id = p.team_id
                WHERE p.team_id='{team_id}' AND p.status = 1";
            sqlConnection.Open();
            sqlCommand = new MySqlCommand(query, sqlConnection);

            object totalPlayer = sqlCommand.ExecuteScalar();

            sqlConnection.Close();

            if (Int32.Parse( totalPlayer.ToString() )<= 11)
            {
                MessageBox.Show("Total Player Less than 12");
                return;
            }
            string player_id = DGV1.SelectedRows[0].Cells[0].Value.ToString();
            string command = $@"UPDATE player SET `status`=0 WHERE player_id='{player_id}'";

            try
            {
                sqlConnection.Open();
                sqlCommand = new MySqlCommand(command, sqlConnection);
                int result = sqlCommand.ExecuteNonQuery();
                if (result < 1)
                {
                    MessageBox.Show("Fail to delete");
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Fail to delete");
                throw;
            }
            finally
            {

                sqlConnection.Close();
            }
            comboBoxTeam2_SelectedIndexChanged(null, null);


        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string manager_id = DGV2.SelectedRows[0].Cells[0].Value.ToString();
            string command = $@"UPDATE manager SET working = 0 WHERE manager_id = '{manager_id}'";

            try
            {
                sqlConnection.Open();
                sqlCommand = new MySqlCommand(command, sqlConnection);
                int result = sqlCommand.ExecuteNonQuery();
                if (result < 1)
                {
                    MessageBox.Show("Fail to delete");
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Fail to delete");
                throw;
            }
            finally
            {

                sqlConnection.Close();
            }
            cbTeam3_SelectedIndexChanged(null, null);
            updateDGVManagerNotWorking();
        }
    }
}
