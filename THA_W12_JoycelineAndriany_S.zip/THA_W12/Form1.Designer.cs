﻿namespace THA_W12
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.lblTeamnum = new System.Windows.Forms.Label();
            this.lblNat = new System.Windows.Forms.Label();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblBirth = new System.Windows.Forms.Label();
            this.lblTeamname1 = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.tbPosition = new System.Windows.Forms.TextBox();
            this.tbHeight = new System.Windows.Forms.TextBox();
            this.tbWeight = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.DGV1 = new System.Windows.Forms.DataGridView();
            this.lblAddPlyr = new System.Windows.Forms.Label();
            this.DGV2 = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.comboBoxNat = new System.Windows.Forms.ComboBox();
            this.tbTeamnum = new System.Windows.Forms.TextBox();
            this.cbTeam1 = new System.Windows.Forms.ComboBox();
            this.lblEdit = new System.Windows.Forms.Label();
            this.lblTeamname2 = new System.Windows.Forms.Label();
            this.cbTeam2 = new System.Windows.Forms.ComboBox();
            this.btnEdit = new System.Windows.Forms.Button();
            this.lblDel = new System.Windows.Forms.Label();
            this.DGV3 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDel = new System.Windows.Forms.Button();
            this.cbTeam3 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPlayerid2 = new System.Windows.Forms.Label();
            this.tbPlayerid2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.DGV1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV3)).BeginInit();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(49, 80);
            this.lblName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name";
            // 
            // lblTeamnum
            // 
            this.lblTeamnum.AutoSize = true;
            this.lblTeamnum.Location = new System.Drawing.Point(49, 116);
            this.lblTeamnum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTeamnum.Name = "lblTeamnum";
            this.lblTeamnum.Size = new System.Drawing.Size(74, 13);
            this.lblTeamnum.TabIndex = 1;
            this.lblTeamnum.Text = "Team Number";
            // 
            // lblNat
            // 
            this.lblNat.AutoSize = true;
            this.lblNat.Location = new System.Drawing.Point(49, 153);
            this.lblNat.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNat.Name = "lblNat";
            this.lblNat.Size = new System.Drawing.Size(56, 13);
            this.lblNat.TabIndex = 2;
            this.lblNat.Text = "Nationality";
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.Location = new System.Drawing.Point(49, 192);
            this.lblPosition.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(44, 13);
            this.lblPosition.TabIndex = 3;
            this.lblPosition.Text = "Position";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(49, 231);
            this.lblHeight.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(38, 13);
            this.lblHeight.TabIndex = 4;
            this.lblHeight.Text = "Height";
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.Location = new System.Drawing.Point(49, 270);
            this.lblWeight.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(41, 13);
            this.lblWeight.TabIndex = 5;
            this.lblWeight.Text = "Weight";
            // 
            // lblBirth
            // 
            this.lblBirth.AutoSize = true;
            this.lblBirth.Location = new System.Drawing.Point(49, 309);
            this.lblBirth.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBirth.Name = "lblBirth";
            this.lblBirth.Size = new System.Drawing.Size(49, 13);
            this.lblBirth.TabIndex = 6;
            this.lblBirth.Text = "Birthdate";
            // 
            // lblTeamname1
            // 
            this.lblTeamname1.AutoSize = true;
            this.lblTeamname1.Location = new System.Drawing.Point(49, 346);
            this.lblTeamname1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTeamname1.Name = "lblTeamname1";
            this.lblTeamname1.Size = new System.Drawing.Size(65, 13);
            this.lblTeamname1.TabIndex = 7;
            this.lblTeamname1.Text = "Team Name";
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(133, 78);
            this.tbName.Margin = new System.Windows.Forms.Padding(2);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(121, 20);
            this.tbName.TabIndex = 8;
            // 
            // tbPosition
            // 
            this.tbPosition.Location = new System.Drawing.Point(133, 190);
            this.tbPosition.Margin = new System.Windows.Forms.Padding(2);
            this.tbPosition.Name = "tbPosition";
            this.tbPosition.Size = new System.Drawing.Size(121, 20);
            this.tbPosition.TabIndex = 11;
            // 
            // tbHeight
            // 
            this.tbHeight.Location = new System.Drawing.Point(133, 231);
            this.tbHeight.Margin = new System.Windows.Forms.Padding(2);
            this.tbHeight.Name = "tbHeight";
            this.tbHeight.Size = new System.Drawing.Size(121, 20);
            this.tbHeight.TabIndex = 12;
            // 
            // tbWeight
            // 
            this.tbWeight.Location = new System.Drawing.Point(133, 268);
            this.tbWeight.Margin = new System.Windows.Forms.Padding(2);
            this.tbWeight.Name = "tbWeight";
            this.tbWeight.Size = new System.Drawing.Size(121, 20);
            this.tbWeight.TabIndex = 13;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(133, 309);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(196, 20);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // DGV1
            // 
            this.DGV1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV1.Location = new System.Drawing.Point(369, 54);
            this.DGV1.Margin = new System.Windows.Forms.Padding(2);
            this.DGV1.MultiSelect = false;
            this.DGV1.Name = "DGV1";
            this.DGV1.ReadOnly = true;
            this.DGV1.RowHeadersWidth = 62;
            this.DGV1.RowTemplate.Height = 28;
            this.DGV1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV1.Size = new System.Drawing.Size(257, 369);
            this.DGV1.TabIndex = 17;
            // 
            // lblAddPlyr
            // 
            this.lblAddPlyr.AutoSize = true;
            this.lblAddPlyr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddPlyr.Location = new System.Drawing.Point(81, 13);
            this.lblAddPlyr.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddPlyr.Name = "lblAddPlyr";
            this.lblAddPlyr.Size = new System.Drawing.Size(112, 20);
            this.lblAddPlyr.TabIndex = 18;
            this.lblAddPlyr.Text = "ADD PLAYER";
            // 
            // DGV2
            // 
            this.DGV2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV2.Location = new System.Drawing.Point(665, 54);
            this.DGV2.Margin = new System.Windows.Forms.Padding(2);
            this.DGV2.MultiSelect = false;
            this.DGV2.Name = "DGV2";
            this.DGV2.ReadOnly = true;
            this.DGV2.RowHeadersWidth = 62;
            this.DGV2.RowTemplate.Height = 28;
            this.DGV2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV2.Size = new System.Drawing.Size(253, 369);
            this.DGV2.TabIndex = 19;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(106, 385);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(64, 29);
            this.btnAdd.TabIndex = 20;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBoxNat
            // 
            this.comboBoxNat.FormattingEnabled = true;
            this.comboBoxNat.Location = new System.Drawing.Point(133, 153);
            this.comboBoxNat.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxNat.Name = "comboBoxNat";
            this.comboBoxNat.Size = new System.Drawing.Size(121, 21);
            this.comboBoxNat.TabIndex = 21;
            // 
            // tbTeamnum
            // 
            this.tbTeamnum.Location = new System.Drawing.Point(133, 112);
            this.tbTeamnum.Margin = new System.Windows.Forms.Padding(2);
            this.tbTeamnum.Name = "tbTeamnum";
            this.tbTeamnum.Size = new System.Drawing.Size(121, 20);
            this.tbTeamnum.TabIndex = 9;
            // 
            // cbTeam1
            // 
            this.cbTeam1.FormattingEnabled = true;
            this.cbTeam1.Location = new System.Drawing.Point(133, 344);
            this.cbTeam1.Margin = new System.Windows.Forms.Padding(2);
            this.cbTeam1.Name = "cbTeam1";
            this.cbTeam1.Size = new System.Drawing.Size(121, 21);
            this.cbTeam1.TabIndex = 22;
            // 
            // lblEdit
            // 
            this.lblEdit.AutoSize = true;
            this.lblEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEdit.Location = new System.Drawing.Point(661, 458);
            this.lblEdit.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEdit.Name = "lblEdit";
            this.lblEdit.Size = new System.Drawing.Size(132, 20);
            this.lblEdit.TabIndex = 25;
            this.lblEdit.Text = "EDIT MANAGER";
            // 
            // lblTeamname2
            // 
            this.lblTeamname2.AutoSize = true;
            this.lblTeamname2.Location = new System.Drawing.Point(366, 32);
            this.lblTeamname2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTeamname2.Name = "lblTeamname2";
            this.lblTeamname2.Size = new System.Drawing.Size(65, 13);
            this.lblTeamname2.TabIndex = 26;
            this.lblTeamname2.Text = "Team Name";
            // 
            // cbTeam2
            // 
            this.cbTeam2.FormattingEnabled = true;
            this.cbTeam2.Location = new System.Drawing.Point(505, 29);
            this.cbTeam2.Margin = new System.Windows.Forms.Padding(2);
            this.cbTeam2.Name = "cbTeam2";
            this.cbTeam2.Size = new System.Drawing.Size(121, 21);
            this.cbTeam2.TabIndex = 27;
            this.cbTeam2.SelectedIndexChanged += new System.EventHandler(this.comboBoxTeam2_SelectedIndexChanged);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(665, 427);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(2);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(253, 29);
            this.btnEdit.TabIndex = 28;
            this.btnEdit.Text = "UPDATE";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // lblDel
            // 
            this.lblDel.AutoSize = true;
            this.lblDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDel.Location = new System.Drawing.Point(365, 458);
            this.lblDel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDel.Name = "lblDel";
            this.lblDel.Size = new System.Drawing.Size(151, 20);
            this.lblDel.TabIndex = 29;
            this.lblDel.Text = "DELETE PLAYERS";
            // 
            // DGV3
            // 
            this.DGV3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV3.Location = new System.Drawing.Point(959, 54);
            this.DGV3.Margin = new System.Windows.Forms.Padding(2);
            this.DGV3.Name = "DGV3";
            this.DGV3.RowHeadersWidth = 62;
            this.DGV3.RowTemplate.Height = 28;
            this.DGV3.Size = new System.Drawing.Size(253, 369);
            this.DGV3.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(662, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 31;
            this.label1.Text = "Team Name";
            // 
            // btnDel
            // 
            this.btnDel.Location = new System.Drawing.Point(369, 427);
            this.btnDel.Margin = new System.Windows.Forms.Padding(2);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(257, 29);
            this.btnDel.TabIndex = 32;
            this.btnDel.Text = "DELETE";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // cbTeam3
            // 
            this.cbTeam3.FormattingEnabled = true;
            this.cbTeam3.Location = new System.Drawing.Point(797, 29);
            this.cbTeam3.Margin = new System.Windows.Forms.Padding(2);
            this.cbTeam3.Name = "cbTeam3";
            this.cbTeam3.Size = new System.Drawing.Size(121, 21);
            this.cbTeam3.TabIndex = 33;
            this.cbTeam3.SelectedIndexChanged += new System.EventHandler(this.cbTeam3_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(955, 30);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(223, 20);
            this.label2.TabIndex = 34;
            this.label2.Text = "NON-WORKING MANAGERS";
            // 
            // lblPlayerid2
            // 
            this.lblPlayerid2.AutoSize = true;
            this.lblPlayerid2.Location = new System.Drawing.Point(366, 487);
            this.lblPlayerid2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPlayerid2.Name = "lblPlayerid2";
            this.lblPlayerid2.Size = new System.Drawing.Size(50, 13);
            this.lblPlayerid2.TabIndex = 35;
            this.lblPlayerid2.Text = "Player ID";
            // 
            // tbPlayerid2
            // 
            this.tbPlayerid2.Location = new System.Drawing.Point(420, 484);
            this.tbPlayerid2.Margin = new System.Windows.Forms.Padding(2);
            this.tbPlayerid2.Name = "tbPlayerid2";
            this.tbPlayerid2.Size = new System.Drawing.Size(121, 20);
            this.tbPlayerid2.TabIndex = 36;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1283, 640);
            this.Controls.Add(this.tbPlayerid2);
            this.Controls.Add(this.lblPlayerid2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbTeam3);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DGV3);
            this.Controls.Add(this.lblDel);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.cbTeam2);
            this.Controls.Add(this.lblTeamname2);
            this.Controls.Add(this.lblEdit);
            this.Controls.Add(this.cbTeam1);
            this.Controls.Add(this.comboBoxNat);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.DGV2);
            this.Controls.Add(this.lblAddPlyr);
            this.Controls.Add(this.DGV1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.tbWeight);
            this.Controls.Add(this.tbHeight);
            this.Controls.Add(this.tbPosition);
            this.Controls.Add(this.tbTeamnum);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.lblTeamname1);
            this.Controls.Add(this.lblBirth);
            this.Controls.Add(this.lblWeight);
            this.Controls.Add(this.lblHeight);
            this.Controls.Add(this.lblPosition);
            this.Controls.Add(this.lblNat);
            this.Controls.Add(this.lblTeamnum);
            this.Controls.Add(this.lblName);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblTeamnum;
        private System.Windows.Forms.Label lblNat;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblBirth;
        private System.Windows.Forms.Label lblTeamname1;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.TextBox tbPosition;
        private System.Windows.Forms.TextBox tbHeight;
        private System.Windows.Forms.TextBox tbWeight;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView DGV1;
        private System.Windows.Forms.Label lblAddPlyr;
        private System.Windows.Forms.DataGridView DGV2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ComboBox comboBoxNat;
        private System.Windows.Forms.TextBox tbTeamnum;
        private System.Windows.Forms.ComboBox cbTeam1;
        private System.Windows.Forms.Label lblEdit;
        private System.Windows.Forms.Label lblTeamname2;
        private System.Windows.Forms.ComboBox cbTeam2;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Label lblDel;
        private System.Windows.Forms.DataGridView DGV3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.ComboBox cbTeam3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblPlayerid2;
        private System.Windows.Forms.TextBox tbPlayerid2;
    }
}

